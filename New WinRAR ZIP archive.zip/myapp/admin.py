from django.contrib import admin
from .models import dicts

admin.site.register(dicts)